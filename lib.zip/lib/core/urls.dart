class DocFFAffordableYoga {
  static const String apphudApiKey = '';
  static const String pP = 'https://pub.dev/';
  static const String tUse = 'https://pub.dev/';
  static const String s = 'https://pub.dev/';
}
